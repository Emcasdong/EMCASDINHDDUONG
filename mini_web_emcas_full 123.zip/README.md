Mini web EMCAS - Đầy đủ tính BMI, TDEE, lời khuyên, thực đơn 7 ngày.
Hướng dẫn: Upload GitHub Pages.